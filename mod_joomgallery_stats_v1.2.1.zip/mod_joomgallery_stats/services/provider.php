<?php
/**
 * @package     mod_joomgallery_stats
 * @copyright   (C) 2026 vodkomotornik.ru
 * @license     GNU General Public License v3 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Vodkomotornik\\Module\\JoomgalleryStats'));
        $container->registerServiceProvider(new Module());
    }
};