<?php
/**
 * @package     mod_joomgallery_stats
 * @copyright   (C) 2026 vodkomotornik.ru
 * @license     GNU General Public License v3 or later
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;

JLoader::registerNamespace('Vodkomotornik\Module\JoomgalleryStats', __DIR__ . '/src', false, false, 'psr4');

use Vodkomotornik\Module\JoomgalleryStats\Site\Helper\JoomgallerystatsHelper;

$jgInstalled = false;
$manifestPath = JPATH_ADMINISTRATOR . '/components/com_joomgallery/joomgallery.xml';

if (\Joomla\CMS\Component\ComponentHelper::isEnabled('com_joomgallery') && file_exists($manifestPath)) {
    $manifest = simplexml_load_file($manifestPath);
    if ($manifest && isset($manifest->version)) {
        $version = (string) $manifest->version;
        $jgInstalled = version_compare($version, '4.0', '>=');
    }
}

$list = [];
$debugMode = (int) $params->get('debug', 0);

if ($jgInstalled) {
    try {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $helper = new JoomgallerystatsHelper($db);
        $list = $helper->getList($params, $debugMode);
    } catch (\Exception $e) {
        if ($debugMode) {
            // Создаем элемент ошибки
            $errorElem = new \stdClass();
            $errorElem->enabled = true;
            $errorElem->outputtext = 'MOD_JOOMGALLERY_STATS_ERROR';
            $errorElem->outputresult = 0;
            $errorElem->error = $e->getMessage();
            $errorElem->dbquerylog = '';
            $list['error'] = $errorElem;
        }
    }
}

$moduleclass_sfx = $params->get('moduleclass_sfx', '');

require ModuleHelper::getLayoutPath('mod_joomgallery_stats', $params->get('layout', 'default'));