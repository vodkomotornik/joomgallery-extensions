<?php
/**
 * @package     mod_joomgallery_stats
 * @copyright   (C) 2026 vodkomotornik.ru
 * @license     GNU General Public License v3 or later
 */

namespace Vodkomotornik\Module\JoomgalleryStats\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
use Vodkomotornik\Module\JoomgalleryStats\Site\Helper\JoomgallerystatsHelper;

class Dispatcher extends AbstractModuleDispatcher
{
    protected function getLayoutData(): array
    {
        $data = parent::getLayoutData();
        
        $params = $data['params'] ?? new Registry();
        $debugMode = (bool) $params->get('debug', 0);
        
        // Преобразуем params в Registry если нужно
        if (!$params instanceof Registry) {
            $params = new Registry((array) $params);
        }
        
        $jgInstalled = $this->checkJoomGallery();
        $list = [];
        
        if ($jgInstalled) {
            try {
                // Получаем DB через контейнер
                $db = Factory::getContainer()->get(DatabaseInterface::class);
                $helper = new JoomgallerystatsHelper($db);
                $list = $helper->getList($params, $debugMode);
            } catch (\Exception $e) {
                if ($debugMode) {
                    $list['error'] = $this->createErrorElement($e->getMessage());
                }
            }
        }
        
        $data['list'] = $list;
        $data['jgInstalled'] = $jgInstalled;
        $data['debugMode'] = $debugMode;
        
        return $data;
    }
    
    private function checkJoomGallery(): bool
    {
        // Проверяем включен ли компонент
        if (!\Joomla\CMS\Component\ComponentHelper::isEnabled('com_joomgallery')) {
            return false;
        }
        
        // Проверяем версию через манифест
        $manifestPath = JPATH_ADMINISTRATOR . '/components/com_joomgallery/joomgallery.xml';
        
        if (!file_exists($manifestPath)) {
            return false;
        }
        
        $manifest = simplexml_load_file($manifestPath);
        if (!$manifest || !isset($manifest->version)) {
            return false;
        }
        
        $version = (string) $manifest->version;
        return version_compare($version, '4.0', '>=');
    }
    
    private function createErrorElement(string $message): \stdClass
    {
        $error = new \stdClass();
        $error->enabled = true;
        $error->outputtext = 'MOD_JOOMGALLERY_STATS_ERROR';
        $error->outputresult = 0;
        $error->error = $message;
        $error->dbquerylog = '';
        return $error;
    }
}