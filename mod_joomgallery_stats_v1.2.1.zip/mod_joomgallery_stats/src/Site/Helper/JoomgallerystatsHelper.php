<?php
/**
 * @package     mod_joomgallery_stats
 * @copyright   (C) 2026 vodkomotornik.ru
 * @license     GNU General Public License v3 or later
 */

namespace Vodkomotornik\Module\JoomgalleryStats\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;

class JoomgallerystatsHelper
{
    private DatabaseInterface $db;
    
    public function __construct(DatabaseInterface $db)
    {
        $this->db = $db;
    }
    
    public function getList($params, $debugMode)
    {
        // Convert params to Registry if it's an array or string
        if (is_array($params)) {
            $params = new Registry($params);
        } elseif (is_string($params)) {
            $params = new Registry();
        } elseif (!($params instanceof Registry)) {
            $params = new Registry();
        }
        
        $elems = [];
        $user = Factory::getApplication()->getIdentity();
        $groups = $user->getAuthorisedViewLevels();
        
        // Безопасное экранирование уровней доступа
        $quotedGroups = implode(',', array_map([$this->db, 'quote'], $groups));

        // 1. Total images
        $elems['allpics'] = $this->createElement($params, 'all_pics', 'all_picstext');
        if ($elems['allpics']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('COUNT(a.id)')
                ->from($this->db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($this->db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($this->db->quoteName('a.published') . ' = 1')
                ->where($this->db->quoteName('a.approved') . ' = 1')
                ->where($this->db->quoteName('a.hidden') . ' = 0')
                ->where($this->db->quoteName('a.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('c.hidden') . ' = 0')
                ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.password') . ' = ' . $this->db->quote(''));
            $elems['allpics']->query = $query;
        }

        // 2. Total categories (exclude root)
        $elems['allcats'] = $this->createElement($params, 'all_cats', 'all_catstext');
        if ($elems['allcats']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('COUNT(c.id)')
                ->from($this->db->quoteName('#__joomgallery_categories', 'c'))
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('c.id') . ' != 1')
                ->where($this->db->quoteName('c.hidden') . ' = 0')
                ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')');
            $elems['allcats']->query = $query;
        }

        // 3. Total hits
        $elems['allhits'] = $this->createElement($params, 'all_hits', 'all_hitstext');
        if ($elems['allhits']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('SUM(a.hits)')
                ->from($this->db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($this->db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($this->db->quoteName('a.published') . ' = 1')
                ->where($this->db->quoteName('a.approved') . ' = 1')
                ->where($this->db->quoteName('a.hidden') . ' = 0')
                ->where($this->db->quoteName('a.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('c.hidden') . ' = 0')
                ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.password') . ' = ' . $this->db->quote(''));
            $elems['allhits']->query = $query;
        }

        // 4. Comments (JoomGallery native)
        $elems['allcomments'] = $this->createElement($params, 'all_comments', 'all_commentstext');
        if ($elems['allcomments']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('COUNT(com.id)')
                ->from($this->db->quoteName('#__joomgallery_comments', 'com'))
                ->innerJoin($this->db->quoteName('#__joomgallery', 'a') . ' ON com.imgid = a.id')
                ->innerJoin($this->db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($this->db->quoteName('com.published') . ' = 1')
                ->where($this->db->quoteName('com.approved') . ' = 1')
                ->where($this->db->quoteName('a.published') . ' = 1')
                ->where($this->db->quoteName('a.approved') . ' = 1')
                ->where($this->db->quoteName('a.hidden') . ' = 0')
                ->where($this->db->quoteName('a.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('c.hidden') . ' = 0')
                ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.password') . ' = ' . $this->db->quote(''));
            $elems['allcomments']->query = $query;
        }

        // 5. Comments (JComments integration)
        $elems['alljcomments'] = $this->createElement($params, 'all_jcomments', 'all_jcommentstext');
        if ($elems['alljcomments']->enabled) {
            $jcommentsMode = $params->get('jcomments_mode', 'strict');
            if ($jcommentsMode === 'fast') {
                $query = $this->db->getQuery(true)
                    ->select('COUNT(jc.id)')
                    ->from($this->db->quoteName('#__jcomments', 'jc'))
                    ->where($this->db->quoteName('jc.published') . ' = 1')
                    ->where($this->db->quoteName('jc.deleted') . ' = 0')
                    ->where($this->db->quoteName('jc.object_group') . ' = ' . $this->db->quote('com_joomgallery'));
            } else {
                $query = $this->db->getQuery(true)
                    ->select('COUNT(jc.id)')
                    ->from($this->db->quoteName('#__jcomments', 'jc'))
                    ->innerJoin($this->db->quoteName('#__joomgallery', 'a') . ' ON jc.object_id = a.id')
                    ->innerJoin($this->db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                    ->where($this->db->quoteName('jc.published') . ' = 1')
                    ->where($this->db->quoteName('jc.deleted') . ' = 0')
                    ->where($this->db->quoteName('jc.object_group') . ' = ' . $this->db->quote('com_joomgallery'))
                    ->where($this->db->quoteName('a.published') . ' = 1')
                    ->where($this->db->quoteName('a.approved') . ' = 1')
                    ->where($this->db->quoteName('a.hidden') . ' = 0')
                    ->where($this->db->quoteName('a.access') . ' IN (' . $quotedGroups . ')')
                    ->where($this->db->quoteName('c.published') . ' = 1')
                    ->where($this->db->quoteName('c.hidden') . ' = 0')
                    ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')')
                    ->where($this->db->quoteName('c.password') . ' = ' . $this->db->quote(''));
            }
            $elems['alljcomments']->query = $query;
        }

        // 6. Total votes
        $elems['allvotes'] = $this->createElement($params, 'all_votes', 'all_votestext');
        if ($elems['allvotes']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('SUM(a.votes)')
                ->from($this->db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($this->db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($this->db->quoteName('a.published') . ' = 1')
                ->where($this->db->quoteName('a.approved') . ' = 1')
                ->where($this->db->quoteName('a.hidden') . ' = 0')
                ->where($this->db->quoteName('a.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.published') . ' = 1')
                ->where($this->db->quoteName('c.hidden') . ' = 0')
                ->where($this->db->quoteName('c.access') . ' IN (' . $quotedGroups . ')')
                ->where($this->db->quoteName('c.password') . ' = ' . $this->db->quote(''));
            $elems['allvotes']->query = $query;
        }

        // 7. Total tags
        $elems['alltags'] = $this->createElement($params, 'all_tags', 'all_tagstext');
        if ($elems['alltags']->enabled) {
            $query = $this->db->getQuery(true)
                ->select('COUNT(t.id)')
                ->from($this->db->quoteName('#__joomgallery_tags', 't'))
                ->where($this->db->quoteName('t.published') . ' = 1')
                ->where($this->db->quoteName('t.access') . ' IN (' . $quotedGroups . ')');
            $elems['alltags']->query = $query;
        }

        // Execute queries and collect results
        foreach ($elems as &$elem) {
            if ($elem->enabled && isset($elem->query)) {
                $this->db->setQuery($elem->query);
                try {
                    $elem->outputresult = (int) $this->db->loadResult();
                } catch (\Exception $e) {
                    $elem->outputresult = 0;
                    if ($debugMode) {
                        $elem->error = $e->getMessage();
                    }
                }
            }
        }

        // Build debug log if enabled
        if ($debugMode) {
            foreach ($elems as &$elem) {
                if ($elem->enabled) {
                    $debugInfo = [];
                    if (!empty($elem->query)) {
                        $queryText = $elem->query instanceof \Joomla\Database\QueryInterface
                            ? $elem->query->__toString()
                            : (string) $elem->query;
                        $debugInfo[] = '<strong>SQL:</strong> <code>' . htmlspecialchars($queryText, ENT_QUOTES, 'UTF-8') . '</code>';
                    }
                    if (isset($elem->outputresult)) {
                        $debugInfo[] = '<strong>Result:</strong> ' . number_format((int) $elem->outputresult, 0, '.', ' ');
                    }
                    if (!empty($elem->error)) {
                        $debugInfo[] = '<strong class="text-danger">Error:</strong> <span class="text-danger">' . htmlspecialchars($elem->error, ENT_QUOTES, 'UTF-8') . '</span>';
                    }
                    $elem->dbquerylog = implode('<br />', $debugInfo);
                }
            }
        }

        return $elems;
    }

    private function createElement($params, $enabledKey, $textKey)
    {
        $elem = new \stdClass();
        $elem->enabled = (int) $params->get($enabledKey, 0);
        $elem->outputresult = 0;
        $elem->outputtext = '';
        $elem->query = null;
        $elem->error = null;
        $elem->dbquerylog = '';
        
        if ($elem->enabled) {
            $elem->outputtext = $params->get($textKey, '');
        }
        
        return $elem;
    }
}