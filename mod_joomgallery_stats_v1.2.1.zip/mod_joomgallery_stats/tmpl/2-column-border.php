<?php
/**
* @package     JoomGallery
* @subpackage  mod_joomgallery_stats
*/
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;


$moduleclassSfx = !empty($moduleclass_sfx) ? htmlspecialchars($moduleclass_sfx, ENT_QUOTES, 'UTF-8') : '';

if (!$jgInstalled) : ?>
<div class="alert alert-warning">
    <?php echo Text::_('MOD_JOOMGALLERY_STATS_JOOMGALLERY_NOT_INSTALLED'); ?>
</div>
<?php else :

    $enabledElements = array_filter($list, function($item) {
        return $item->enabled;
    });
    $half = ceil(count($enabledElements) / 2);
    $firstColumn = array_slice($enabledElements, 0, $half);
    $secondColumn = array_slice($enabledElements, $half);
?>
<div class="joomgallery-stats<?php echo $moduleclassSfx ? ' ' . $moduleclassSfx : ''; ?>">
    <div class="row">
        <!-- 001 -->
        <div class="col-12 col-md-6">
            <?php foreach ($firstColumn as $listelem) : ?>
                <div class="border-bottom border-1 mb-1 d-flex justify-content-between">
                    <span class="joomgallery-stats-text">
                        <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_QUOTES, 'UTF-8'); ?>
                    </span>
                    <span class="joomgallery-stats-result fw-semibold">
                        <?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?>
                    </span>
                </div>
                <?php if (!empty($listelem->error)) : ?>
                    <div class="text-danger small mb-2">
                        <?php echo htmlspecialchars($listelem->error, ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
        
        <!-- 002 -->
        <?php if (!empty($secondColumn)) : ?>
            <div class="col-12 col-md-6">
                <?php foreach ($secondColumn as $listelem) : ?>
                    <div class="border-bottom border-1 mb-1 d-flex justify-content-between">
                        <span class="joomgallery-stats-text">
                            <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_QUOTES, 'UTF-8'); ?>
                        </span>
                        <span class="joomgallery-stats-result fw-semibold">
                            <?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?>
                        </span>
                    </div>
                    <?php if (!empty($listelem->error)) : ?>
                        <div class="text-danger small mb-2">
                            <?php echo htmlspecialchars($listelem->error, ENT_QUOTES, 'UTF-8'); ?>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- debugMode -->
    <?php if ($debugMode) : ?>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card bg-light border-primary">
                    <div class="card-header bg-primary text-white fw-bold">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-bug" viewBox="0 0 16 16">
                            <path d="M7.2 1.3a1 1 0 0 1 1.6 0l.397.894c.1.226.23.434.384.618l.537-.27a1 1 0 0 1 1.146.143l.645.645a1 1 0 0 1 .143 1.146l-.27.537c.184.154.392.284.618.384l.894-.397a1 1 0 0 1 0 1.6l-.894.397c-.226.1-.434.23-.618.384l.27.537a1 1 0 0 1-.143 1.146l-.645.645a1 1 0 0 1-1.146.143l-.537-.27c-.154.184-.284.392-.384.618l.397.894a1 1 0 0 1-1.6 0l-.397-.894a2.002 2.002 0 0 0-.384-.618l-.537.27a1 1 0 0 1-1.146-.143L4.35 8.645a1 1 0 0 1-.143-1.146l.27-.537a2.002 2.002 0 0 0-.618-.384l-.894.397a1 1 0 0 1 0-1.6l.894-.397c.226-.1.434-.23.618-.384l-.27-.537a1 1 0 0 1 .143-1.146L5.35 2.35a1 1 0 0 1 1.146-.143l.537.27c.154-.184.284-.392.384-.618L7.2 1.3zm.8 2.7a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/>
                        </svg>
                        DEBUG
                    </div>
                    <div class="card-body">
                        <?php foreach ($list as $listelem) : ?>
                            <?php if ($listelem->enabled && !empty($listelem->dbquerylog)) : ?>
                                <div class="mb-3 pb-3 border-bottom">
                                    <strong class="fs-5">
                                        <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_QUOTES, 'UTF-8'); ?>
                                    </strong>
                                    <?php if (!empty($listelem->outputresult)) : ?>
                                        <span class="badge bg-secondary ms-2">
                                            <?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?>
                                        </span>
                                    <?php endif; ?>
                                    <div class="bg-white border rounded p-2 mt-2">
                                        <small><?php echo $listelem->dbquerylog; // Уже экранировано в Helper ?></small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>