<?php
/**
 * @package     JoomGallery
 * @subpackage  mod_joomgallery_stats
 */

defined('_JEXEC') or die;

// 1. Сначала use
use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Factory;
use JoomGallery\Module\Joomgallerystats\Helper\JoomgallerystatsHelper;

// 2. Потом принудительное подключение (гарантия работы)
require_once __DIR__ . '/src/Helper/JoomgallerystatsHelper.php';

// 3. Получаем параметры с значениями по умолчанию
$moduleclass_sfx = $params->get('moduleclass_sfx', ''); // Добавлено значение по умолчанию
$debugMode = (int) $params->get('debug', 0);

// 4. Остальной код
$jgInstalled = false;
$jgMinVersion = '4.0';

$manifestPath = JPATH_ROOT . '/administrator/components/com_joomgallery/joomgallery.xml';
if (file_exists($manifestPath)) {
    $manifest = simplexml_load_file($manifestPath);
    if ($manifest && isset($manifest->version)) {
        $jgVersion = (string) $manifest->version;
        if (version_compare($jgVersion, $jgMinVersion, '>=')) {
            $jgInstalled = true;
        }
    }
}

$list = [];

if ($jgInstalled) {
    $helper = new JoomgallerystatsHelper();
    $list = $helper->getList($params, $debugMode);
}

require ModuleHelper::getLayoutPath('mod_joomgallery_stats', $params->get('layout', 'default'));