<?php
/**
 * @package     JoomGallery
 * @subpackage  mod_joomgallery_stats
 */
namespace JoomGallery\Module\Joomgallerystats\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\ParameterType;

class JoomgallerystatsHelper
{
    public function getList(&$params, $debugMode)
    {
        $elems = [];
        $db    = Factory::getContainer()->get('DatabaseDriver');
        $user  = Factory::getApplication()->getIdentity();
        $groups = implode(',', $user->getAuthorisedViewLevels());

        // 1. Изображения
        $elems['allpics'] = $this->createElement($params, 'all_pics', 'all_picstext');
        if ($elems['allpics']->enabled) {
            $query = $db->getQuery(true)
                ->select('COUNT(a.id)')
                ->from($db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($db->quoteName('a.published') . ' = 1')
                ->where($db->quoteName('a.approved') . ' = 1')
                ->where($db->quoteName('a.hidden') . ' = 0')
                ->where($db->quoteName('a.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.published') . ' = 1')
                ->where($db->quoteName('c.hidden') . ' = 0')
                ->where($db->quoteName('c.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.password') . ' = ' . $db->quote(''));
            $elems['allpics']->query = $query;
        }

        // 2. Категории
        $elems['allcats'] = $this->createElement($params, 'all_cats', 'all_catstext');
        if ($elems['allcats']->enabled) {
            $query = $db->getQuery(true)
                ->select('COUNT(c.id)')
                ->from($db->quoteName('#__joomgallery_categories', 'c'))
                ->where($db->quoteName('c.published') . ' = 1')
                ->where($db->quoteName('c.id') . ' != 1')
                ->where($db->quoteName('c.hidden') . ' = 0')
                ->where($db->quoteName('c.access') . ' IN (' . $groups . ')');
            $elems['allcats']->query = $query;
        }

        // 3. Просмотры
        $elems['allhits'] = $this->createElement($params, 'all_hits', 'all_hitstext');
        if ($elems['allhits']->enabled) {
            $query = $db->getQuery(true)
                ->select('SUM(a.hits)')
                ->from($db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($db->quoteName('a.published') . ' = 1')
                ->where($db->quoteName('a.approved') . ' = 1')
                ->where($db->quoteName('a.hidden') . ' = 0')
                ->where($db->quoteName('a.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.published') . ' = 1')
                ->where($db->quoteName('c.hidden') . ' = 0')
                ->where($db->quoteName('c.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.password') . ' = ' . $db->quote(''));
            $elems['allhits']->query = $query;
        }

        // 4. Комментарии (JoomGallery)
        $elems['allcomments'] = $this->createElement($params, 'all_comments', 'all_commentstext');
        if ($elems['allcomments']->enabled) {
            $query = $db->getQuery(true)
                ->select('COUNT(com.id)')
                ->from($db->quoteName('#__joomgallery_comments', 'com'))
                ->innerJoin($db->quoteName('#__joomgallery', 'a') . ' ON com.imgid = a.id')
                ->innerJoin($db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($db->quoteName('com.published') . ' = 1')
                ->where($db->quoteName('com.approved') . ' = 1')
                ->where($db->quoteName('a.published') . ' = 1')
                ->where($db->quoteName('a.approved') . ' = 1')
                ->where($db->quoteName('a.hidden') . ' = 0')
                ->where($db->quoteName('a.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.published') . ' = 1')
                ->where($db->quoteName('c.hidden') . ' = 0')
                ->where($db->quoteName('c.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.password') . ' = ' . $db->quote(''));
            $elems['allcomments']->query = $query;
        }

        // 5. Комментарии (JComments)
        $elems['alljcomments'] = $this->createElement($params, 'all_jcomments', 'all_jcommentstext');
        if ($elems['alljcomments']->enabled) {
            $jcommentsMode = $params->get('jcomments_mode', 'strict');
            if ($jcommentsMode === 'fast') {
                $query = $db->getQuery(true)
                    ->select('COUNT(jc.id)')
                    ->from($db->quoteName('#__jcomments', 'jc'))
                    ->where($db->quoteName('jc.published') . ' = 1')
                    ->where($db->quoteName('jc.deleted') . ' = 0')
                    ->where($db->quoteName('jc.object_group') . ' = ' . $db->quote('com_joomgallery'));
            } else {
                $query = $db->getQuery(true)
                    ->select('COUNT(jc.id)')
                    ->from($db->quoteName('#__jcomments', 'jc'))
                    ->innerJoin($db->quoteName('#__joomgallery', 'a') . ' ON jc.object_id = a.id')
                    ->innerJoin($db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                    ->where($db->quoteName('jc.published') . ' = 1')
                    ->where($db->quoteName('jc.deleted') . ' = 0')
                    ->where($db->quoteName('jc.object_group') . ' = ' . $db->quote('com_joomgallery'))
                    ->where($db->quoteName('a.published') . ' = 1')
                    ->where($db->quoteName('a.approved') . ' = 1')
                    ->where($db->quoteName('a.hidden') . ' = 0')
                    ->where($db->quoteName('a.access') . ' IN (' . $groups . ')')
                    ->where($db->quoteName('c.published') . ' = 1')
                    ->where($db->quoteName('c.hidden') . ' = 0')
                    ->where($db->quoteName('c.access') . ' IN (' . $groups . ')')
                    ->where($db->quoteName('c.password') . ' = ' . $db->quote(''));
            }
            $elems['alljcomments']->query = $query;
        }

        // 6. Оценки
        $elems['allvotes'] = $this->createElement($params, 'all_votes', 'all_votestext');
        if ($elems['allvotes']->enabled) {
            $query = $db->getQuery(true)
                ->select('SUM(a.votes)')
                ->from($db->quoteName('#__joomgallery', 'a'))
                ->innerJoin($db->quoteName('#__joomgallery_categories', 'c') . ' ON c.id = a.catid')
                ->where($db->quoteName('a.published') . ' = 1')
                ->where($db->quoteName('a.approved') . ' = 1')
                ->where($db->quoteName('a.hidden') . ' = 0')
                ->where($db->quoteName('a.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.published') . ' = 1')
                ->where($db->quoteName('c.hidden') . ' = 0')
                ->where($db->quoteName('c.access') . ' IN (' . $groups . ')')
                ->where($db->quoteName('c.password') . ' = ' . $db->quote(''));
            $elems['allvotes']->query = $query;
        }

        // 7. Теги
        $elems['alltags'] = $this->createElement($params, 'all_tags', 'all_tagstext');
        if ($elems['alltags']->enabled) {
            $query = $db->getQuery(true)
                ->select('COUNT(t.id)')
                ->from($db->quoteName('#__joomgallery_tags', 't'))
                ->where($db->quoteName('t.published') . ' = 1')
                ->where($db->quoteName('t.access') . ' IN (' . $groups . ')');
            $elems['alltags']->query = $query;
        }

        // Выполнение запросов
        foreach ($elems as &$elem) {
            if ($elem->enabled && isset($elem->query)) {
                $db->setQuery($elem->query);
                try {
                    $elem->outputresult = $db->loadResult();
                    if ($elem->outputresult === null) {
                        $elem->outputresult = 0;
                    }
                } catch (\Exception $e) {
                    $elem->outputresult = 0;
                    if ($debugMode) {
                        $elem->error = $e->getMessage();
                    }
                }
            }
        }

        // Логирование отладки (ИСПРАВЛЕНО - без getLog())
        if ($debugMode) {
            foreach ($elems as &$elem) {
                if ($elem->enabled) {
                    $debugInfo = [];
                    
                    if (!empty($elem->query)) {
                        $queryText = $elem->query instanceof \Joomla\Database\QueryInterface 
                            ? $elem->query->__toString() 
                            : (string) $elem->query;
                        $debugInfo[] = '<strong>SQL:</strong> <code>' . htmlspecialchars($queryText, ENT_QUOTES, 'UTF-8') . '</code>';
                    }
                    
                    if (isset($elem->outputresult)) {
                        $debugInfo[] = '<strong>Результат:</strong> ' . number_format((int) $elem->outputresult, 0, '.', ' ');
                    }
                    
                    if (!empty($elem->error)) {
                        $debugInfo[] = '<strong class="text-danger">Ошибка:</strong> <span class="text-danger">' . htmlspecialchars($elem->error, ENT_QUOTES, 'UTF-8') . '</span>';
                    }
                    
                    $elem->dbquerylog = implode('<br />', $debugInfo);
                }
            }
        }

        return $elems;
    }

    private function createElement(&$params, $enabledKey, $textKey)
    {
        $elem = new \stdClass();
        $elem->enabled = (int) $params->get($enabledKey, 0);
        if ($elem->enabled) {
            $elem->outputtext = $params->get($textKey, '');
        }
        return $elem;
    }
}