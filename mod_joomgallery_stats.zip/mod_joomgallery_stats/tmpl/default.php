<?php
/**
 * @package     JoomGallery
 * @subpackage  mod_joomgallery_stats
 */
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

if (!$jgInstalled) : ?>
    <div class="alert alert-warning">
        <?php echo Text::_('MOD_JOOMGALLERY_STATS_JOOMGALLERY_NOT_INSTALLED'); ?>
    </div>
<?php else : ?>
    <ul class="list-unstyled joomgallery-stats-<?php echo htmlspecialchars($moduleclass_sfx ?? ''); ?>">
        <?php foreach ($list as $listelem) : ?>
            <?php if ($listelem->enabled) : ?>
                <li class="mb-2 d-flex justify-content-between">
                    <span class="joomgallery-stats-text">
                        <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_COMPAT, 'UTF-8'); ?>
                    </span>
                    <span class="joomgallery-stats-result fw-bold">
                        <?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?>
                    </span>
                </li>
                <?php if (!empty($listelem->error)) : ?>
                    <div class="text-danger small mb-2">
                        <?php echo htmlspecialchars($listelem->error); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </ul>

    <!-- БЛОК DEBUG -->
    <?php if ($debugMode) : ?>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card bg-light border-primary">
                    <div class="card-header bg-primary text-white fw-bold">
                        🐞 DEBUG
                    </div>
                    <div class="card-body">
                        <?php foreach ($list as $listelem) : ?>
                            <?php if ($listelem->enabled && !empty($listelem->dbquerylog)) : ?>
                                <div class="mb-3 pb-3 border-bottom">
                                    <strong class="fs-5">
                                        <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_COMPAT, 'UTF-8'); ?>
                                    </strong>
                                    <?php if (!empty($listelem->outputresult)) : ?>
                                        <span class="badge bg-secondary ms-2">
                                            <?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?>
                                        </span>
                                    <?php endif; ?>
                                    <div class="bg-white border rounded p-2 mt-2">
                                        <small><?php echo $listelem->dbquerylog; ?></small>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>