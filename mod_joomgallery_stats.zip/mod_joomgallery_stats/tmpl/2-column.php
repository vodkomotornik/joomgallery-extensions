<?php
/**
 * @package     JoomGallery
 * @subpackage  mod_joomgallery_stats
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

if (!$jgInstalled) : ?>
    <div class="alert alert-warning">
        <?php echo Text::_('MOD_JOOMGALLERY_STATS_JOOMGALLERY_NOT_INSTALLED'); ?>
    </div>
<?php else : 
    // Разбиваем элементы на две колонки
    $enabledElements = array_filter($list, function($item) {
        return $item->enabled;
    });
    $half = ceil(count($enabledElements) / 2);
    $firstColumn = array_slice($enabledElements, 0, $half);
    $secondColumn = array_slice($enabledElements, $half);
?>
    <div class="joomgallery-stats-<?php echo htmlspecialchars($moduleclass_sfx ?? ''); ?>">
        <div class="row">
            <!-- Первая колонка -->
            <div class="col-12 col-md-6">
                <?php foreach ($firstColumn as $listelem) : ?>
                    <div class="mb-1 d-flex justify-content-between border-bottom">
                        <span class="joomgallery-stats-text"> <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_COMPAT, 'UTF-8'); ?></span>
                        <span class="joomgallery-stats-result fw-semibold"><?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?></span>
                    </div>
                    <?php if ($debugMode && !empty($listelem->dbquerylog)) : ?>
                        <div class="text-muted small mb-2"><?php echo $listelem->dbquerylog; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($listelem->error)) : ?>
                        <div class="text-danger small mb-2"><?php echo htmlspecialchars($listelem->error); ?></div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            
            <!-- Вторая колонка -->
            <?php if (!empty($secondColumn)) : ?>
            <div class="col-12 col-md-6">
                <?php foreach ($secondColumn as $listelem) : ?>
                    <div class="mb-1 d-flex justify-content-between border-bottom">
                        <span class="joomgallery-stats-text"> <?php echo htmlspecialchars(Text::_($listelem->outputtext), ENT_COMPAT, 'UTF-8'); ?></span>
                        <span class="joomgallery-stats-result fw-semibold"><?php echo number_format((int) $listelem->outputresult, 0, '.', ' '); ?></span>
                    </div>
                    <?php if ($debugMode && !empty($listelem->dbquerylog)) : ?>
                        <div class="text-muted small mb-2"><?php echo $listelem->dbquerylog; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($listelem->error)) : ?>
                        <div class="text-danger small mb-2"><?php echo htmlspecialchars($listelem->error); ?></div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>