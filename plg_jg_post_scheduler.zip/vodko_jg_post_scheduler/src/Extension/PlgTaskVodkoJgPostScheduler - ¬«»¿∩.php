<?php
namespace Vodkomotornik\Plugin\Task\VodkoJgPostScheduler\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

final class PlgTaskVodkoJgPostScheduler extends CMSPlugin implements SubscriberInterface
{
    use TaskPluginTrait;

    protected $autoloadLanguage = true;

    private const TASKS_MAP = [
        'vodko_jg_post_scheduler' => [
            'langConstPrefix' => 'PLG_TASK_VODKO_JG_POST_SCHEDULER',
            'method'          => 'publishImages',
        ],
    ];

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList' => 'advertiseRoutines',
            'onExecuteTask'     => 'standardRoutineHandler',
        ];
    }

    private function publishImages(ExecuteTaskEvent $event): int
    {
        /** @var Registry $params */
        $params     = new Registry($event->getArgument('params'));
        $limit      = (int) $params->get('batch_limit', 1);
        $maxAgeDays = (int) $params->get('max_age_days', 7);
        $debug      = (int) $params->get('debug_mode', 0);

        $db = Factory::getDbo();

        // Берём текущее время в часовом поясе сайта (совпадает с тем, что вы видите в админке)
        $currentDate = Factory::getDate()->toSql();

        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__joomgallery'))
            ->where($db->quoteName('published') . ' = 0')
            ->where($db->quoteName('date') . ' <= ' . $db->quote($currentDate))
            ->where($db->quoteName('date') . ' IS NOT NULL')
            ->where($db->quoteName('date') . ' != ' . $db->quote('0000-00-00 00:00:00'));

        if ($maxAgeDays > 0) {
            // Фото старше указанного количества дней игнорируются
            $maxAgeDate = Factory::getDate("-{$maxAgeDays} days")->toSql();
            $query->where($db->quoteName('date') . ' > ' . $db->quote($maxAgeDate));
        }

        $query->order($db->quoteName('date') . ' ASC')
              ->setLimit($limit);

        $db->setQuery($query);
        $photoIds = $db->loadColumn();

        if (empty($photoIds)) {
            if ($debug) {
                $this->logTask('Нет фото, готовых к публикации (текущее время сайта: ' . $currentDate . ')', 'debug');
            }
            return Status::OK;
        }

        // Безопасная подготовка ID
        $safeIds = array_map('intval', $photoIds);

        $updateQuery = $db->getQuery(true)
            ->update($db->quoteName('#__joomgallery'))
            ->set($db->quoteName('published') . ' = 1')
            ->where($db->quoteName('id') . ' IN (' . implode(',', $safeIds) . ')');

        $db->setQuery($updateQuery);
        $db->execute();

        $count = count($safeIds);
        $this->logTask(sprintf('Успешно опубликовано %d фото', $count), 'info');

        return Status::OK;
    }
}