<?php
namespace Vodkomotornik\Plugin\Task\VodkoJgPostScheduler\Extension;

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Component\Scheduler\Administrator\Event\ExecuteTaskEvent;
use Joomla\Component\Scheduler\Administrator\Task\Status;
use Joomla\Component\Scheduler\Administrator\Traits\TaskPluginTrait;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

final class PlgTaskVodkoJgPostScheduler extends CMSPlugin implements SubscriberInterface
{
    use TaskPluginTrait;

    protected $autoloadLanguage = true;

    private const TASKS_MAP = [
        'vodko_jg_post_scheduler' => [
            'langConstPrefix' => 'PLG_TASK_VODKO_JG_POST_SCHEDULER',
            'method'          => 'publishImages',
        ],
    ];

    public static function getSubscribedEvents(): array
    {
        return [
            'onTaskOptionsList' => 'advertiseRoutines',
            'onExecuteTask'     => 'standardRoutineHandler',
        ];
    }

    private function publishImages(ExecuteTaskEvent $event): int
    {
        $params      = new Registry($event->getArgument('params'));
        $limit       = (int) $params->get('batch_limit', 1);
        $maxAgeDays  = (int) $params->get('max_age_days', 7);
        $debug       = (int) $params->get('debug_mode', 0);
        $enableEmail = (int) $params->get('enable_email_notifications', 0);
        $emailTo     = trim($params->get('notification_email', ''));

        $db = Factory::getDbo();
        $currentTime = Factory::getDate()->toSql();

        $query = $db->getQuery(true)
            ->select($db->quoteName('id'))
            ->from($db->quoteName('#__joomgallery'))
            ->where($db->quoteName('published') . ' = 0')
            ->where($db->quoteName('hidden') . ' = 0')
            ->where($db->quoteName('date') . ' <= ' . $db->quote($currentTime))
            ->where($db->quoteName('date') . ' IS NOT NULL')
            ->where($db->quoteName('date') . ' != ' . $db->quote('0000-00-00 00:00:00'));

        if ($maxAgeDays > 0) {
            $query->where($db->quoteName('date') . ' > ' . $db->quote(Factory::getDate("-{$maxAgeDays} days")->toSql()));
        }

        $query->order($db->quoteName('date') . ' ASC')->setLimit($limit);

        try {
            $db->setQuery($query);
            $photoIds = $db->loadColumn();

            if (empty($photoIds)) {
                if ($debug) $this->logTask('Нет фото для публикации', 'debug');
                return Status::OK;
            }

            $safeIds = array_map('intval', $photoIds);
            $db->setQuery(
                $db->getQuery(true)->update($db->quoteName('#__joomgallery'))
                   ->set($db->quoteName('published') . ' = 1')
                   ->where($db->quoteName('id') . ' IN (' . implode(',', $safeIds) . ')')
            );
            $db->execute();

            $count = count($safeIds);
            $msg = "Опубликовано {$count} фото";
            $this->logTask($msg, 'info');

            if ($enableEmail && filter_var($emailTo, FILTER_VALIDATE_EMAIL)) {
                $this->sendEmail($emailTo, 'Отложенный постинг: успех', $msg);
            }

            return Status::OK;

        } catch (\Exception $e) {
            $err = 'Ошибка: ' . $e->getMessage();
            $this->logTask($err, 'error');
            if ($enableEmail && filter_var($emailTo, FILTER_VALIDATE_EMAIL)) {
                $this->sendEmail($emailTo, 'Отложенный постинг: ошибка', $err);
            }
            return Status::KNOCKOUT;
        }
    }

    private function sendEmail(string $to, string $subject, string $body): void
    {
        try {
            $app = Factory::getApplication();
            $mailer = Factory::getMailer();

            $mailer->setSender([
                $app->get('mailfrom', 'noreply@site.com'),
                $app->get('fromname', 'Site Scheduler')
            ]);
            $mailer->addRecipient($to);
            $mailer->setSubject($subject);
            $mailer->setBody($body);
            $mailer->isHtml(false);
            $mailer->Send();

            if ($this->params->get('debug_mode', 0)) {
                $this->logTask('Email отправлен на ' . $to, 'debug');
            }
        } catch (\Exception $e) {
            $this->logTask('Ошибка почты: ' . $e->getMessage(), 'error');
        }
    }
}