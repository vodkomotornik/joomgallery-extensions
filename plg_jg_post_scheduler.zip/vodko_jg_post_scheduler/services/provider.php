<?php
namespace Vodkomotornik\Plugin\Task\VodkoJgPostScheduler\Service;

\defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Event\DispatcherInterface;
use Vodkomotornik\Plugin\Task\VodkoJgPostScheduler\Extension\PlgTaskVodkoJgPostScheduler;

return new class () implements ServiceProviderInterface {
    public function register(Container $container)
    {
        $container->set(
            PluginInterface::class,
            function (Container $container) {
                $plugin = new PlgTaskVodkoJgPostScheduler(
                    $container->get(DispatcherInterface::class),
                    (array) PluginHelper::getPlugin('task', 'vodko_jg_post_scheduler')
                );
                $plugin->setApplication(Factory::getApplication());
                return $plugin;
            }
        );
    }
};