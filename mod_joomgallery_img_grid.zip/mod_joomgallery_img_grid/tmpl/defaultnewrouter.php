<?php
/**
 * @package     mod_joomgallery_img_grid
 * @copyright   (C) 2025 JoomGallery Team. All rights reserved.
 * @license     Free to distribute
 */
defined('_JEXEC') or die;

use Joomgallery\Component\Joomgallery\Administrator\Helper\JoomHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

if (!isset($images)) {
    echo Text::_('MOD_JOOMGALLERY_IMG_GRID_ERROR_DATABASE');
    return;
}

if (empty($images)) {
    if ($params->get('show_empty_message', 1)) {
        echo '<div class="alert alert-info">' . Text::_('MOD_JOOMGALLERY_IMG_GRID_NO_IMAGES') . '</div>';
    }
    return;
}

$columns = (int) $params->get('columns', 3);
$colClass = 'col-md-' . (12 / $columns);
$thumbBase = trim($params->get('thumb_path', ''), '/');
$showTitle = $params->get('show_title', 1);
$showCategory = $params->get('show_category', 1);
$linkCategory = (int) $params->get('link_category', 1);
$showHits = $params->get('show_hits', 1);
$showDate = $params->get('show_date', 1);
$showRating = $params->get('show_rating', 1);
$showDescription = $params->get('show_cut_text', 0);

// --- ЛОГИКА ДОБАВЛЕНИЯ ЯКОРЯ ---
$rawAnchor = trim((string)$params->get('anchor', ''));
$finalAnchor = '';
if ($rawAnchor !== '') {
    // Если якорь введен без решетки в начале, добавляем её автоматически
    $finalAnchor = (strpos($rawAnchor, '#') === 0) ? $rawAnchor : '#' . ltrim($rawAnchor, '#/');
}
// ------------------------------

?>
<div class="mod-joomgallery-img-grid <?php echo $params->get('moduleclass_sfx'); ?>">
    <div class="row">
    <?php foreach ($images as $image) :
        $categoryPath = !empty($image->category_path) ? $image->category_path . '/' : '';
        $imgSrc = Uri::root() . $thumbBase . '/' . $categoryPath . $image->filename;
        
        // 1. Формируем правильную SEF-ссылку через стандартный роутер Joomla
        $baseLink = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $image->id . '&catid=' . (int) $image->catid);
        
        // 2. Добавляем якорь к концу ссылки
        $imgLink = $baseLink . $finalAnchor;

        $imageDate = '';
        if (!empty($image->date) && $image->date !== '0000-00-00 00:00:00') {
            try {
                $imageDate = HTMLHelper::date($image->date, 'd.m.Y', true);
            } catch (\Exception $e) {
                $imageDate = '';
            }
        }
    ?>
        <div class="<?php echo $colClass; ?> mb-0">
            <div class="card h-100 p-1 text-center border-0">
                <!-- Ссылка на изображении -->
                <a href="<?php echo htmlspecialchars($imgLink, ENT_QUOTES, 'UTF-8'); ?>">
                    <img src="<?php echo $imgSrc; ?>"
                         alt="<?php echo htmlspecialchars($image->title); ?>"
                         class="img-fluid"
                         loading="lazy"
                         onerror="this.style.display='none'">
                </a>
                
                <?php if ($showTitle || $showCategory || $showHits || $showDate || $showRating || $showDescription) : ?>
                <div class="card-body py-1">
                    <?php if ($showTitle) : ?>
                    <h5 class="card-title mt-1">
                        <!-- Ссылка в заголовке -->
                        <a href="<?php echo htmlspecialchars($imgLink, ENT_QUOTES, 'UTF-8'); ?>" class="card-link fs-7 text-decoration-none">
                            <?php echo htmlspecialchars($image->title); ?>
                        </a>
                    </h5>
                    <?php endif; ?>
                    
                    <!-- Вывод описания -->
                    <?php if ($showDescription && !empty($image->description)) : ?>
                    <p class="card-text small text-muted lh-1 mb-1">
                        <?php echo htmlspecialchars($image->description); ?>
                    </p>
                    <?php endif; ?>
                    
					<?php if ($showCategory && !empty($image->category_title)) : ?>
						<?php
						$catLink = '';
						if ($linkCategory && (int) $image->catid > 0) {
							$catLink = Route::_('index.php?option=com_joomgallery&view=category&id=' . (int) $image->catid);
						}
						?>
						<p class="card-text small text-muted mb-1">
							<span class="icon-folder pe-1" aria-hidden="true"></span>
							<?php if ($catLink) : ?>
								<a href="<?php echo htmlspecialchars($catLink, ENT_QUOTES, 'UTF-8'); ?>"
								   class="text-decoration-none"
								   title="<?php echo htmlspecialchars($image->category_title, ENT_QUOTES, 'UTF-8'); ?>">
									<?php echo htmlspecialchars($image->category_title, ENT_QUOTES, 'UTF-8'); ?>
								</a>
							<?php else : ?>
								<?php echo htmlspecialchars($image->category_title, ENT_QUOTES, 'UTF-8'); ?>
							<?php endif; ?>
						</p>
					<?php endif; ?>
                    
                    <div class="d-flex flex-wrap gap-2 small justify-content-center">
                        <?php if ($showHits) : ?>
                        <span class="badge bg-info">
                            <span class="icon-eye pe-1" aria-hidden="true"></span>
                            <?php echo (int) $image->hits; ?>
                        </span>
                        <?php endif; ?>
                        
                        <?php if ($showDate && $imageDate) : ?>
                        <span class="badge bg-info">
                            <span class="icon-calendar pe-1" aria-hidden="true"></span>
                            <?php echo $imageDate; ?>
                        </span>
                        <?php endif; ?>
                        
                        <?php if ($showRating && $image->votes > 0) : ?>
                        <span class="badge bg-info">
                            <span class="icon-star text-danger" aria-hidden="true"></span>
                            <?php echo number_format($image->rating, 1); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</div>