<?php
defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

// Force register namespace (ensures class loading even if autoloader cache is stale)
JLoader::registerNamespace('Vodkomotornik\Module\JoomImagesGrid', __DIR__ . '/src', false, false, 'psr4');
use Vodkomotornik\Module\JoomImagesGrid\Site\Helper\JoomImagesHelper;

if (!ComponentHelper::isEnabled('com_joomgallery')) {
    echo Text::_('MOD_JOOMGALLERY_IMG_GRID_ERROR_COMPONENT_NOT_ENABLED');
    return;
}

$app  = Factory::getApplication();
$db   = Factory::getDbo();
$images = JoomImagesHelper::getImages($params, $app, $db);

$rawAnchor = trim((string)$params->get('anchor'));
$finalAnchor = '';

if ($rawAnchor !== '') {
    // Если ввели текст без решетки - добавляем её
    $finalAnchor = (strpos($rawAnchor, '#') === 0) ? $rawAnchor : '#' . ltrim($rawAnchor, '#/');
}

// Добавляем итоговый якорь к каждой картинке
foreach ($images as &$image) {
    $baseLink = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int)$image->id . '&catid=' . (int)$image->catid);
    
    $image->finalUrl = $baseLink . $finalAnchor; 
}
unset($image);

require ModuleHelper::getLayoutPath('mod_joomgallery_img_grid', $params->get('layout', 'default'));