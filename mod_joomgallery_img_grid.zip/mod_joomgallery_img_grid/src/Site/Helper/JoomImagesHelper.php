<?php
namespace Vodkomotornik\Module\JoomImagesGrid\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

class JoomImagesHelper
{
    public static function getImages($params, $app, $db)
    {
        if (!$db) {
            $db = Factory::getDbo();
        }

        $categories = (array) $params->get('categories', []);
        $count      = max(1, (int) $params->get('count', 9));
        $sorting    = (string) $params->get('sorting', 'date');
        $order      = strtoupper(trim((string) $params->get('order', 'DESC'))) === 'ASC' ? 'ASC' : 'DESC';

        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('a.id'), $db->quoteName('a.catid'), $db->quoteName('a.title'),
                $db->quoteName('a.description'), $db->quoteName('a.filename'),
                $db->quoteName('a.hits'), $db->quoteName('a.votes'), $db->quoteName('a.votesum'),
                $db->quoteName('a.date'), $db->quoteName('a.published'),
                $db->quoteName('a.hidden'), $db->quoteName('a.approved'), $db->quoteName('a.access'),
                $db->quoteName('c.title', 'category_title'),
                $db->quoteName('c.published', 'category_published'),
                $db->quoteName('c.access', 'category_access'),
                $db->quoteName('c.path', 'category_path')
            ])
            ->from($db->quoteName('#__joomgallery', 'a'))
            ->join(
                'LEFT',
                $db->quoteName('#__joomgallery_categories', 'c'),
                $db->quoteName('a.catid') . ' = ' . $db->quoteName('c.id')
            )
            ->where($db->quoteName('a.published') . ' = 1')
            ->where($db->quoteName('a.approved') . ' = 1')
            ->where($db->quoteName('a.hidden') . ' = 0')
            ->where($db->quoteName('c.published') . ' = 1')
            ->where($db->quoteName('c.hidden') . ' = 0');

        if (!empty($categories)) {
            $query->whereIn($db->quoteName('a.catid'), array_map('intval', $categories));
        }

        $groups = array_map('intval', Factory::getUser()->getAuthorisedViewLevels());

        if (empty($groups)) {
            $groups = [1];
        }

        $groups = implode(',', $groups);

        $query->where($db->quoteName('a.access') . ' IN (' . $groups . ')');
        $query->where($db->quoteName('c.access') . ' IN (' . $groups . ')');

        if ($sorting === 'random') {
            $query->order($db->getQuery(true)->rand());
        } else {
            switch ($sorting) {
                case 'id':
                    $orderColumn = $db->quoteName('a.id');
                    break;

                case 'hits':
                    $orderColumn = $db->quoteName('a.hits');
                    break;

                case 'rating':
                    $orderColumn = 'COALESCE(' . $db->quoteName('a.votesum') . ' / NULLIF(' . $db->quoteName('a.votes') . ', 0), 0)';
                    break;

                // Старое сохранённое значение из настроек, если осталось
                case 'created_time':
                case 'date':
                default:
                    $orderColumn = $db->quoteName('a.date');
                    break;
            }

            $query->order($orderColumn . ' ' . $order);

            // Чтобы при одинаковых датах порядок был стабильным
            if ($sorting !== 'id') {
                $query->order($db->quoteName('a.id') . ' ' . $order);
            }
        }

        $query->setLimit($count);

        $db->setQuery($query);

        try {
            $images = $db->loadObjectList();
        } catch (\Exception $e) {
            $app->enqueueMessage(Text::_('MOD_JOOMGALLERY_IMG_GRID_ERROR_DATABASE'), 'error');
            return [];
        }

        $showCutText  = (int) $params->get('show_cut_text', 0);
        $cutTextLength = (int) $params->get('cut_text_length', 150);

        foreach ($images as $image) {
            $image->rating = ($image->votes > 0) ? round($image->votesum / $image->votes, 2) : 0;

            if (isset($image->description) && $image->description !== '') {
                $image->description = preg_replace(
                    '/<(br|p|div|hr|h[1-6]|li|tr|td|th|ul|ol|table)[^>]*>/i',
                    ' ',
                    $image->description
                );

                $image->description = strip_tags($image->description);
				$image->description = html_entity_decode($image->description, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $image->description = preg_replace('/\s+/', ' ', $image->description);
                $image->description = trim($image->description);

                if ($showCutText && mb_strlen($image->description, 'UTF-8') > $cutTextLength) {
                    $image->description = mb_substr($image->description, 0, $cutTextLength, 'UTF-8') . '...';
                }
            }
        }

        return $images;
    }
}