<?php
defined('_JEXEC') or die;

use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\CMS\Cache\Controller\OutputController;
use Joomla\CMS\Cache\CacheControllerFactoryInterface;

class PlgJoomgalleryNavigationprevnext extends CMSPlugin
{
    protected $autoloadLanguage = true;
    protected $app;
    protected $db;
    protected $cache;
    
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->app = Factory::getApplication();
        $this->db = Factory::getContainer()->get(DatabaseInterface::class);
        
        try {
            $cacheFactory = Factory::getContainer()->get(CacheControllerFactoryInterface::class);
            $this->cache = $cacheFactory->createCacheController('output', [
                'defaultgroup' => 'plg_joomgallery_navigationprevnext',
                'lifetime' => 3600,
                'storage' => 'file'
            ]);
        } catch (\Exception $e) {
            $this->cache = null;
        }
    }
    
    public function onJoomGalleryAfterDisplayImage($context, &$image, &$params)
    {

        if ($context !== 'com_joomgallery.image') {
            return '';
        }
        
        if (!$this->app->getIdentity()->authorise('core.view', 'com_joomgallery')) {
            return '';
        }
        
        if (!is_object($image) || empty($image->id) || empty($image->catid)) {
            return '';
        }
        
        $this->loadLanguage();
        
        $debugMode = (bool) $this->params->get('debug_mode', 0);
        $showMiniGallery = (bool) $this->params->get('show_mini_gallery', 1);
        
        // DEBUG (только для суперпользователей)
        $debug = '';
        if ($debugMode && $this->app->getIdentity()->authorise('core.admin')) {
            $debug = $this->debugInfo($image);
        }
        
        $previewCount = (int) $this->params->get('preview_count', 5);
        $images = $this->getImagesRangeOptimized($image->catid, $image->id, $previewCount);
        
        if (empty($images)) {
            return $debug ?: '';
        }
        
        $currentKey = $this->findCurrentImageKey($images, $image->id);
        if ($currentKey === null) {
            return $debug ?: '';
        }
        
        $prevItem = $images[$currentKey - 1] ?? null;
        $nextItem = $images[$currentKey + 1] ?? null;
        
        // HTML
        $html = $this->generateHtml($image, $images, $currentKey, $prevItem, $nextItem);
        
        // CSS (только один раз)
        static $cssAdded = false;
        if (!$cssAdded && $showMiniGallery) {
            $doc = $this->app->getDocument();
            $doc->addStyleDeclaration('
                .jg-preview-hover {
                    transition: all 0.3s ease;
                    cursor: pointer;
                }
                .jg-preview-hover:hover {
                    transform: scale(1.02);
                    box-shadow: 0 0 0 1px #0d6efd;
                    z-index: 10;
                }
                .jg-navigation .half-opacity {
                    opacity: 0.7;
                }
                .jg-navigation .half-opacity:hover {
                    opacity: 1;
                }
            ');
            $cssAdded = true;
        }
        
        return $debug . $html;
    }
    
    /*** Получение изображений для мини-галереи (только нужный диапазон) ***/
    private function getImagesRangeOptimized(int $catId, int $currentImageId, int $previewCount): array
    {

        $cacheId = 'img_range_' . $catId . '_' . $currentImageId . '_' . $previewCount;
        if ($this->cache) {
            $cached = $this->cache->get($cacheId);
            if ($cached !== false) {
                return $cached;
            }
        }
        
        $query = $this->db->getQuery(true);
        $query->select($this->db->quoteName('ordering'))
              ->from($this->db->quoteName('#__joomgallery'))
              ->where($this->db->quoteName('id') . ' = :id')
              ->bind(':id', $currentImageId, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $currentOrdering = (int) $this->db->loadResult();
        
        if (!$currentOrdering) {
            return [];
        }
        
        $halfCount = (int) floor($previewCount / 2);
        $images = [];
        
        $query = $this->db->getQuery(true);
        $query->select([
            $this->db->quoteName('id'),
            $this->db->quoteName('title'),
            $this->db->quoteName('filename'),
            $this->db->quoteName('catid'),
            $this->db->quoteName('ordering')
        ])
        ->from($this->db->quoteName('#__joomgallery'))
        ->where($this->db->quoteName('catid') . ' = :catid')
        ->where($this->db->quoteName('published') . ' = 1')
        ->where($this->db->quoteName('ordering') . ' <= :ordering')
        ->order($this->db->quoteName('ordering') . ' DESC')
        ->setLimit($halfCount + 1) // +1 для текущего
        ->bind(':catid', $catId, ParameterType::INTEGER)
        ->bind(':ordering', $currentOrdering, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $before = $this->db->loadObjectList();
        $before = array_reverse($before); // Переворачиваем для правильного порядка
        
        $query = $this->db->getQuery(true);
        $query->select([
            $this->db->quoteName('id'),
            $this->db->quoteName('title'),
            $this->db->quoteName('filename'),
            $this->db->quoteName('catid'),
            $this->db->quoteName('ordering')
        ])
        ->from($this->db->quoteName('#__joomgallery'))
        ->where($this->db->quoteName('catid') . ' = :catid')
        ->where($this->db->quoteName('published') . ' = 1')
        ->where($this->db->quoteName('ordering') . ' > :ordering')
        ->order($this->db->quoteName('ordering') . ' ASC')
        ->setLimit($halfCount)
        ->bind(':catid', $catId, ParameterType::INTEGER)
        ->bind(':ordering', $currentOrdering, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $after = $this->db->loadObjectList();
        
        $images = array_merge($before, $after);
        
        if (count($images) < $previewCount) {
            $needMore = $previewCount - count($images);
            
            if (count($before) <= $halfCount + 1) {
                $lastOrdering = !empty($after) ? end($after)->ordering : $currentOrdering;
                $more = $this->getImagesAfterOrdering($catId, $lastOrdering, $needMore);
                $images = array_merge($images, $more);
            } else {
                $firstOrdering = $before[0]->ordering;
                $more = $this->getImagesBeforeOrdering($catId, $firstOrdering, $needMore);
                $images = array_merge($more, $images);
            }
        }
        
        if ($this->cache && !empty($images)) {
            $this->cache->store($images, $cacheId);
        }
        
        return $images;
    }
    
    private function getImagesAfterOrdering(int $catId, int $ordering, int $limit): array
    {
        $query = $this->db->getQuery(true);
        $query->select([
            $this->db->quoteName('id'),
            $this->db->quoteName('title'),
            $this->db->quoteName('filename'),
            $this->db->quoteName('catid'),
            $this->db->quoteName('ordering')
        ])
        ->from($this->db->quoteName('#__joomgallery'))
        ->where($this->db->quoteName('catid') . ' = :catid')
        ->where($this->db->quoteName('published') . ' = 1')
        ->where($this->db->quoteName('ordering') . ' > :ordering')
        ->order($this->db->quoteName('ordering') . ' ASC')
        ->setLimit($limit)
        ->bind(':catid', $catId, ParameterType::INTEGER)
        ->bind(':ordering', $ordering, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        return $this->db->loadObjectList();
    }

    private function getImagesBeforeOrdering(int $catId, int $ordering, int $limit): array
    {
        $query = $this->db->getQuery(true);
        $query->select([
            $this->db->quoteName('id'),
            $this->db->quoteName('title'),
            $this->db->quoteName('filename'),
            $this->db->quoteName('catid'),
            $this->db->quoteName('ordering')
        ])
        ->from($this->db->quoteName('#__joomgallery'))
        ->where($this->db->quoteName('catid') . ' = :catid')
        ->where($this->db->quoteName('published') . ' = 1')
        ->where($this->db->quoteName('ordering') . ' < :ordering')
        ->order($this->db->quoteName('ordering') . ' DESC')
        ->setLimit($limit)
        ->bind(':catid', $catId, ParameterType::INTEGER)
        ->bind(':ordering', $ordering, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $images = $this->db->loadObjectList();
        return array_reverse($images);
    }
    
    private function findCurrentImageKey(array $images, int $imageId): ?int
    {
        foreach ($images as $key => $img) {
            if ((int) $img->id === $imageId) {
                return $key;
            }
        }
        return null;
    }
    
    /*** HTML NAV ***/
    private function generateHtml($image, array $images, int $currentKey, $prevItem, $nextItem): string
    {
        $showMiniGallery = (bool) $this->params->get('show_mini_gallery', 1);
        $showNavButtons = (bool) $this->params->get('show_nav_buttons', 1);
        $showTitles = (bool) $this->params->get('show_titles', 1);
        $iconChevron = (bool) $this->params->get('icon_chevron', 0);
        $previewSize = (int) $this->params->get('preview_size', 100);
        
        $html = '<div class="jg-navigation my-2">';
        
        if ($showMiniGallery) {
            $html .= $this->generateMiniGallery($images, $currentKey, $image->catid, $previewSize, $iconChevron);
        }
        
        if ($showNavButtons || $showTitles) {
            $html .= $this->generateBottomNav($images, $currentKey, $prevItem, $nextItem, $image->catid, $showNavButtons, $showTitles);
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
private function generateMiniGallery(array $images, int $currentKey, int $catId, int $previewSize, bool $iconChevron): string
{
    $html = '<div class="d-flex align-items-center justify-content-center gap-2 mb-1">';
    
    if ($iconChevron) {
        $firstImage = $this->getFirstImageInCategory($catId);
        if ($firstImage && (int) $firstImage->id !== (int) $images[$currentKey]->id) {
            $link = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $firstImage->id . '&catid=' . $catId);
            $html .= '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '#image-title" 
                         class="text-decoration-none" 
                         title="' . htmlspecialchars(Text::_('PLG_JOOMGALLERY_NAVIGATION_FIRST_IMAGE'), ENT_QUOTES, 'UTF-8') . '">';
            $html .= '<span class="fa-solid fa-chevron-left" style="font-size:2rem;line-height:1;" aria-hidden="true"></span>';
            $html .= '</a>';
        } else {
            $html .= '<span class="fa-solid fa-chevron-left" style="font-size:2rem;line-height:1;opacity:0.25;" aria-hidden="true"></span>';
        }
    }
    
    $html .= '<div class="d-flex gap-2 flex-nowrap half-opacity">';
    
    foreach ($images as $key => $item) {
        $isCurrent = ($key === $currentKey);
        $thumbUrl = $this->getThumbnailPath($item);
        $link = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $item->id . '&catid=' . $catId);
        
        $html .= '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '#image-title" 
                     class="text-decoration-none" 
                     title="' . htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8') . '">';
        
        if ($thumbUrl) {
            $html .= '<div class="ratio ratio-1x1 rounded jg-preview-hover" style="border: ' . ($isCurrent ? '2px solid #0d6efd' : '1px solid #dee2e6') . '; width: min(' . (int) $previewSize . 'px, 15vw);">';
            $html .= '<img src="' . htmlspecialchars($thumbUrl, ENT_QUOTES, 'UTF-8') . '" 
                           alt="' . htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8') . '" 
                           class="object-fit-cover" 
                           loading="lazy">';
            $html .= '</div>';
        } else {
            $html .= '<div class="ratio ratio-1x1 rounded bg-light d-flex align-items-center justify-content-center jg-preview-hover" style="border: ' . ($isCurrent ? '3px solid #0d6efd' : '1px solid #dee2e6') . '; width: min(' . (int) $previewSize . 'px, 15vw);">';
            $html .= '<i class="fa-regular fa-image" style="font-size:24px;" aria-hidden="true"></i>';
            $html .= '</div>';
        }
        
        $html .= '</a>';
    }
    
    $html .= '</div>';
    
    if ($iconChevron) {
        $lastImage = $this->getLastImageInCategory($catId);
        if ($lastImage && (int) $lastImage->id !== (int) $images[$currentKey]->id) {
            $link = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $lastImage->id . '&catid=' . $catId);
            $html .= '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '#image-title" 
                         class="text-decoration-none" 
                         title="' . htmlspecialchars(Text::_('PLG_JOOMGALLERY_NAVIGATION_LAST_IMAGE'), ENT_QUOTES, 'UTF-8') . '">';
            $html .= '<span class="fa-solid fa-chevron-right" style="font-size: 2rem; line-height: 1;" aria-hidden="true"></span>';
            $html .= '</a>';
        } else {
            $html .= '<span class="fa-solid fa-chevron-right" style="font-size:2rem;line-height:1;opacity:0.25;" aria-hidden="true"></span>';
        }
    }
    
    $html .= '</div>';
    
    return $html;
}

private function getFirstImageInCategory(int $catId): ?stdClass
{
    $cacheId = 'first_image_cat_' . $catId;
    
    if ($this->cache) {
        $cached = $this->cache->get($cacheId);
        if ($cached !== false) {
            return $cached;
        }
    }
    
    $query = $this->db->getQuery(true);
    $query->select([
        $this->db->quoteName('id'),
        $this->db->quoteName('title')
    ])
    ->from($this->db->quoteName('#__joomgallery'))
    ->where($this->db->quoteName('catid') . ' = :catid')
    ->where($this->db->quoteName('published') . ' = 1')
    ->order($this->db->quoteName('ordering') . ' ASC')
    ->setLimit(1)
    ->bind(':catid', $catId, ParameterType::INTEGER);
    
    $this->db->setQuery($query);
    $image = $this->db->loadObject();
    
    if ($this->cache && $image) {
        $this->cache->store($image, $cacheId);
    }
    
    return $image;
}

	private function getLastImageInCategory(int $catId): ?stdClass
	{
		$cacheId = 'last_image_cat_' . $catId;
    
		if ($this->cache) {
			$cached = $this->cache->get($cacheId);
			if ($cached !== false) {
				return $cached;
			}
		}
    
		$query = $this->db->getQuery(true);
		$query->select([
			$this->db->quoteName('id'),
			$this->db->quoteName('title')
		])
		->from($this->db->quoteName('#__joomgallery'))
		->where($this->db->quoteName('catid') . ' = :catid')
		->where($this->db->quoteName('published') . ' = 1')
		->order($this->db->quoteName('ordering') . ' DESC')
		->setLimit(1)
		->bind(':catid', $catId, ParameterType::INTEGER);
    
		$this->db->setQuery($query);
		$image = $this->db->loadObject();
    
		if ($this->cache && $image) {
			$this->cache->store($image, $cacheId);
		}
    
		return $image;
	}
    
    private function generateBottomNav(array $images, int $currentKey, $prevItem, $nextItem, int $catId, bool $showNavButtons, bool $showTitles): string
    {
        $html = '<div class="d-flex justify-content-between align-items-center mt-2">';
        
        if ($showNavButtons) {
            if ($prevItem) {
                $link = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $prevItem->id . '&catid=' . $catId);
                $prevTitle = htmlspecialchars($prevItem->title, ENT_QUOTES, 'UTF-8');
                $html .= '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '#image-title" class="btn btn-primary btn-sm" title="' . $prevTitle . '">';
                $html .= '<span class="fa-solid fa-chevron-left" aria-hidden="true"></span> ' . htmlspecialchars(Text::_('COM_JOOMGALLERY_PREV_IMAGE'), ENT_QUOTES, 'UTF-8');
                $html .= '</a>';
            } else {
                $html .= '<div></div>';
            }
        } else {
            $html .= '<div></div>';
        }
        
        if ($showTitles) {
            $totalImages = $this->getTotalImagesInCategory($catId);
            $current = $this->getImagePosition($catId, $images[$currentKey]->id);
            $html .= '<div class="text-center fs-7">' . htmlspecialchars(Text::_('COM_JOOMGALLERY_IMAGE'), ENT_QUOTES, 'UTF-8') . ' ' . $current . ' / ' . $totalImages . '</div>';
        } else {
            $html .= '<div class="text-center"></div>';
        }
        
        if ($showNavButtons) {
            if ($nextItem) {
                $link = Route::_('index.php?option=com_joomgallery&view=image&id=' . (int) $nextItem->id . '&catid=' . $catId);
                $nextTitle = htmlspecialchars($nextItem->title, ENT_QUOTES, 'UTF-8');
                $html .= '<a href="' . htmlspecialchars($link, ENT_QUOTES, 'UTF-8') . '#image-title" class="btn btn-primary btn-sm" title="' . $nextTitle . '">';
                $html .= htmlspecialchars(Text::_('COM_JOOMGALLERY_NEXT_IMAGE'), ENT_QUOTES, 'UTF-8') . ' <span class="icon-chevron-right" aria-hidden="true"></span>';
                $html .= '</a>';
            } else {
                $html .= '<div></div>';
            }
        } else {
            $html .= '<div></div>';
        }
        
        $html .= '</div>';
        
        return $html;
    }
    
    private function getImagePosition(int $catId, int $imageId): int
    {
        $cacheId = 'img_position_' . $catId . '_' . $imageId;
        
        if ($this->cache) {
            $cached = $this->cache->get($cacheId);
            if ($cached !== false) {
                return (int) $cached;
            }
        }
        
        $query = $this->db->getQuery(true);
        $query->select('COUNT(*) + 1 as position')
              ->from($this->db->quoteName('#__joomgallery'))
              ->where($this->db->quoteName('catid') . ' = :catid')
              ->where($this->db->quoteName('published') . ' = 1')
              ->where($this->db->quoteName('ordering') . ' < (
                  SELECT ' . $this->db->quoteName('ordering') . '
                  FROM ' . $this->db->quoteName('#__joomgallery') . '
                  WHERE id = :image_id
              )')
              ->bind(':catid', $catId, ParameterType::INTEGER)
              ->bind(':image_id', $imageId, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $position = (int) $this->db->loadResult();
        
        if ($this->cache) {
            $this->cache->store($position, $cacheId);
        }
        
        return $position;
    }
    
    private function getTotalImagesInCategory(int $catId): int
    {
        $cacheId = 'total_images_cat_' . $catId;
        
        if ($this->cache) {
            $cached = $this->cache->get($cacheId);
            if ($cached !== false) {
                return (int) $cached;
            }
        }
        
        $query = $this->db->getQuery(true);
        $query->select('COUNT(*)')
              ->from($this->db->quoteName('#__joomgallery'))
              ->where($this->db->quoteName('catid') . ' = :catid')
              ->where($this->db->quoteName('published') . ' = 1')
              ->bind(':catid', $catId, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $total = (int) $this->db->loadResult();
        
        if ($this->cache) {
            $this->cache->store($total, $cacheId, 86400); // Кеш на 24 часа
        }
        
        return $total;
    }
    
    private function getThumbnailPath($item): string
    {
        $thumbPath = $this->params->get('thumb_path', 'images/gallery/thumb');
        $thumbPath = trim($thumbPath, '/');
        $basePath = JPATH_ROOT . '/' . $thumbPath;
        
        $fullCatPath = $this->getFullCategoryPath($item->catid);
        
        if (!empty($fullCatPath)) {
            $path = $basePath . '/' . $fullCatPath . '/' . $item->filename;
            if (is_file($path)) {
                return str_replace(JPATH_ROOT, '', $path);
            }
        }
        
        $catAlias = $this->getCategoryAlias($item->catid);
        if (!empty($catAlias)) {
            $path = $basePath . '/' . $catAlias . '/' . $item->filename;
            if (is_file($path)) {
                return str_replace(JPATH_ROOT, '', $path);
            }
        }
        
        // Fallback
        $path = $basePath . '/' . $item->filename;
        if (is_file($path)) {
            return str_replace(JPATH_ROOT, '', $path);
        }
        
        return '';
    }
    
    /*** Alias category ***/
    private function getCategoryAlias(int $catId): string
    {
        $cacheId = 'cat_alias_' . $catId;
        
        if ($this->cache) {
            $cached = $this->cache->get($cacheId);
            if ($cached !== false) {
                return $cached;
            }
        }
        
        $query = $this->db->getQuery(true);
        $query->select($this->db->quoteName('alias'))
              ->from($this->db->quoteName('#__joomgallery_categories'))
              ->where($this->db->quoteName('id') . ' = :id')
              ->bind(':id', $catId, ParameterType::INTEGER);
        
        $this->db->setQuery($query);
        $alias = $this->db->loadResult() ?: '';
        
        if ($this->cache) {
            $this->cache->store($alias, $cacheId);
        }
        
        return $alias;
    }
    
    private function getFullCategoryPath(int $catId): string
    {
        if ($catId <= 0) {
            return '';
        }
        
        $cacheId = 'cat_path_' . $catId;
        
        if ($this->cache) {
            $cached = $this->cache->get($cacheId);
            if ($cached !== false) {
                return $cached;
            }
        }
        
        $path = [];
        $currentId = $catId;
        $maxDepth = 10;
        
        while ($currentId > 0 && $maxDepth-- > 0) {
            $query = $this->db->getQuery(true);
            $query->select($this->db->quoteName(['id', 'alias', 'parent_id']))
                  ->from($this->db->quoteName('#__joomgallery_categories'))
                  ->where($this->db->quoteName('id') . ' = :id')
                  ->bind(':id', $currentId, ParameterType::INTEGER);
            
            $this->db->setQuery($query);
            $category = $this->db->loadObject();
            
            if (!$category) {
                break;
            }
            
            array_unshift($path, $category->alias);
            $currentId = (int) $category->parent_id;
        }
        
        $fullPath = implode('/', $path);
        $fullPath = preg_replace('/^root\//', '', $fullPath);
        
        if ($this->cache) {
            $this->cache->store($fullPath, $cacheId);
        }
        
        return $fullPath;
    }
    
    /*** DebugInfo ***/
    private function debugInfo($image): string
    {
        if (!is_object($image)) {
            return '<div class="alert alert-danger"><strong>🔍 DEBUG:</strong> image не является объектом</div>';
        }
        
        $debug = '<div class="alert alert-info" style="background:#f0f0f0; padding:15px; margin:10px 0; border:2px solid #ff0000; border-radius:5px; font-family:monospace;">';
        $debug .= '<h4 style="margin-top:0; color:#ff0000;">🔍 DEBUG Режим</h4>';
        
        $debug .= '<h5>📷 Информация о текущем изображении:</h5>';
        $debug .= '<ul>';
        $debug .= '<li><strong>ID:</strong> ' . htmlspecialchars($image->id ?? 'нет', ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Заголовок:</strong> ' . htmlspecialchars($image->title ?? 'нет', ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Категория ID:</strong> ' . htmlspecialchars($image->catid ?? 'нет', ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Имя файла:</strong> ' . htmlspecialchars($image->filename ?? 'нет', ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Ordering:</strong> ' . htmlspecialchars($image->ordering ?? 'нет', ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '</ul>';
        
        $debug .= '<h5>⚙️ Настройки плагина:</h5>';
        $debug .= '<ul>';
        $debug .= '<li><strong>Путь к миниатюрам:</strong> ' . htmlspecialchars($this->params->get('thumb_path', 'images/gallery/thumb'), ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Количество превью:</strong> ' . (int) $this->params->get('preview_count', 3) . '</li>';
        $debug .= '<li><strong>Размер превью:</strong> ' . (int) $this->params->get('preview_size', 100) . 'px</li>';
        $debug .= '<li><strong>Показывать мини-галерею:</strong> ' . ((bool) $this->params->get('show_mini_gallery', 1) ? '✅ Да' : '❌ Нет') . '</li>';
        $debug .= '<li><strong>Показывать кнопки:</strong> ' . ((bool) $this->params->get('show_nav_buttons', 1) ? '✅ Да' : '❌ Нет') . '</li>';
        $debug .= '<li><strong>Показывать названия:</strong> ' . ((bool) $this->params->get('show_titles', 1) ? '✅ Да' : '❌ Нет') . '</li>';
        $debug .= '<li><strong>Иконки шевронов:</strong> ' . ((bool) $this->params->get('icon_chevron', 0) ? '✅ Да' : '❌ Нет') . '</li>';
        $debug .= '</ul>';
        
        $totalImages = $this->getTotalImagesInCategory($image->catid);
        $currentPosition = $this->getImagePosition($image->catid, $image->id);
        $catAlias = $this->getCategoryAlias($image->catid);
        $fullPath = $this->getFullCategoryPath($image->catid);
        
        $debug .= '<h5>📁 Информация о категории:</h5>';
        $debug .= '<ul>';
        $debug .= '<li><strong>Alias категории:</strong> ' . htmlspecialchars($catAlias, ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Полный путь:</strong> ' . htmlspecialchars($fullPath, ENT_QUOTES, 'UTF-8') . '</li>';
        $debug .= '<li><strong>Всего изображений:</strong> ' . $totalImages . '</li>';
        $debug .= '<li><strong>Позиция текущего:</strong> ' . $currentPosition . ' из ' . $totalImages . '</li>';
        $debug .= '</ul>';
        
        $debug .= '</div>';
        
        return $debug;
    }
}